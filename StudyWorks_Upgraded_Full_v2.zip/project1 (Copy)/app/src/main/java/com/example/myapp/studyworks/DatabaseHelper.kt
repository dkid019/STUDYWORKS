package com.example.myapp.studyworks

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "StudyWorks.db"
        private const val DATABASE_VERSION = 3  // bumped from 2 → 3 for cover_image column

        private const val TABLE_USERS = "users"
        private const val COL_ID = "id"
        private const val COL_FIRST_NAME = "first_name"
        private const val COL_LAST_NAME = "last_name"
        private const val COL_USERNAME = "username"
        private const val COL_PASSWORD = "password"

        private const val TABLE_CLASSES = "classes"
        private const val COL_CLASS_ID = "class_id"
        private const val COL_CLASS_NAME = "class_name"
        private const val COL_SECTION = "section"
        private const val COL_SCHEDULE = "schedule"
        private const val COL_ROOM = "room"
        private const val COL_LEVEL = "level"
        private const val COL_CODE = "code"
        private const val COL_COVER_IMAGE = "cover_image"   // NEW

        private const val TABLE_ENROLLMENTS = "enrollments"
        private const val COL_ENROLL_ID = "enroll_id"
        private const val COL_ENROLL_STUDENT = "student_name"
        private const val COL_ENROLL_CLASS_ID = "class_id"
        private const val COL_ENROLL_SECTION = "section"
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE $TABLE_USERS ("
                    + "$COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + "$COL_FIRST_NAME TEXT,"
                    + "$COL_LAST_NAME TEXT,"
                    + "$COL_USERNAME TEXT UNIQUE,"
                    + "$COL_PASSWORD TEXT)"
        )

        db.execSQL(
            "CREATE TABLE $TABLE_CLASSES ("
                    + "$COL_CLASS_ID TEXT PRIMARY KEY,"
                    + "$COL_CLASS_NAME TEXT,"
                    + "$COL_SECTION TEXT,"
                    + "$COL_SCHEDULE TEXT,"
                    + "$COL_ROOM TEXT,"
                    + "$COL_LEVEL TEXT,"
                    + "$COL_CODE TEXT,"
                    + "$COL_COVER_IMAGE TEXT DEFAULT '')"   // NEW column
        )

        db.execSQL(
            "CREATE TABLE $TABLE_ENROLLMENTS ("
                    + "$COL_ENROLL_ID INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + "$COL_ENROLL_STUDENT TEXT,"
                    + "$COL_ENROLL_CLASS_ID TEXT,"
                    + "$COL_ENROLL_SECTION TEXT,"
                    + "UNIQUE($COL_ENROLL_STUDENT, $COL_ENROLL_CLASS_ID))"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Migrate v2 → v3: just add the cover_image column (preserves existing data)
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE $TABLE_CLASSES ADD COLUMN $COL_COVER_IMAGE TEXT DEFAULT ''")
        }
        // If upgrading from even older versions, recreate tables
        if (oldVersion < 2) {
            db.execSQL("DROP TABLE IF EXISTS $TABLE_USERS")
            db.execSQL("DROP TABLE IF EXISTS $TABLE_CLASSES")
            db.execSQL("DROP TABLE IF EXISTS $TABLE_ENROLLMENTS")
            onCreate(db)
        }
    }

    fun deleteClass(classId: String) {
        val db = this.writableDatabase
        db.delete(TABLE_CLASSES, "$COL_CLASS_ID=?", arrayOf(classId))
        db.close()
    }

    fun updateClass(classData: ClassData) {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COL_CLASS_NAME, classData.className)
            put(COL_SECTION, classData.section)
            put(COL_SCHEDULE, classData.schedule)
            put(COL_ROOM, classData.roomNumber)
            put(COL_LEVEL, classData.academicLevel)
            put(COL_CODE, classData.classCode)
            put(COL_COVER_IMAGE, classData.coverImagePath)
        }
        db.update(TABLE_CLASSES, values, "$COL_CLASS_ID=?", arrayOf(classData.id))
        db.close()
    }

    fun addUser(user: UserData): Boolean {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COL_FIRST_NAME, user.firstName)
            put(COL_LAST_NAME, user.lastName)
            put(COL_USERNAME, user.username)
            put(COL_PASSWORD, user.passwordHash)
        }
        val success = db.insert(TABLE_USERS, null, values)
        db.close()
        return success != -1L
    }

    fun checkUser(username: String, passwordHash: String): UserData? {
        val db = this.readableDatabase
        val cursor = db.query(
            TABLE_USERS, null,
            "$COL_USERNAME=? AND $COL_PASSWORD=?",
            arrayOf(username, passwordHash),
            null, null, null
        )
        var user: UserData? = null
        if (cursor.moveToFirst()) {
            user = UserData(
                firstName = cursor.getString(cursor.getColumnIndexOrThrow(COL_FIRST_NAME)),
                lastName = cursor.getString(cursor.getColumnIndexOrThrow(COL_LAST_NAME)),
                username = cursor.getString(cursor.getColumnIndexOrThrow(COL_USERNAME)),
                passwordHash = cursor.getString(cursor.getColumnIndexOrThrow(COL_PASSWORD))
            )
        }
        cursor.close()
        db.close()
        return user
    }

    fun addClass(classData: ClassData) {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COL_CLASS_ID, classData.id)
            put(COL_CLASS_NAME, classData.className)
            put(COL_SECTION, classData.section)
            put(COL_SCHEDULE, classData.schedule)
            put(COL_ROOM, classData.roomNumber)
            put(COL_LEVEL, classData.academicLevel)
            put(COL_CODE, classData.classCode)
            put(COL_COVER_IMAGE, classData.coverImagePath)   // NEW
        }
        db.insert(TABLE_CLASSES, null, values)
        db.close()
    }

    fun getAllClasses(): List<ClassData> {
        val classList = mutableListOf<ClassData>()
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM $TABLE_CLASSES", null)
        if (cursor.moveToFirst()) {
            do {
                // Safely read cover_image (may not exist on old rows before migration)
                val coverIdx = cursor.getColumnIndex(COL_COVER_IMAGE)
                val coverPath = if (coverIdx >= 0) cursor.getString(coverIdx) ?: "" else ""

                classList.add(
                    ClassData(
                        id = cursor.getString(cursor.getColumnIndexOrThrow(COL_CLASS_ID)),
                        className = cursor.getString(cursor.getColumnIndexOrThrow(COL_CLASS_NAME)),
                        section = cursor.getString(cursor.getColumnIndexOrThrow(COL_SECTION)),
                        schedule = cursor.getString(cursor.getColumnIndexOrThrow(COL_SCHEDULE)),
                        roomNumber = cursor.getString(cursor.getColumnIndexOrThrow(COL_ROOM)),
                        academicLevel = cursor.getString(cursor.getColumnIndexOrThrow(COL_LEVEL)),
                        classCode = cursor.getString(cursor.getColumnIndexOrThrow(COL_CODE)),
                        coverImagePath = coverPath   // NEW
                    )
                )
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return classList
    }

    fun addEnrollment(enrollment: StudentEnrollment) {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COL_ENROLL_STUDENT, enrollment.studentName)
            put(COL_ENROLL_CLASS_ID, enrollment.classId)
            put(COL_ENROLL_SECTION, enrollment.section)
        }
        db.insertWithOnConflict(TABLE_ENROLLMENTS, null, values, SQLiteDatabase.CONFLICT_IGNORE)
        db.close()
    }

    fun isEnrolled(studentName: String, classId: String): Boolean {
        val db = this.readableDatabase
        val cursor = db.query(
            TABLE_ENROLLMENTS, arrayOf(COL_ENROLL_ID),
            "$COL_ENROLL_STUDENT=? AND $COL_ENROLL_CLASS_ID=?",
            arrayOf(studentName, classId),
            null, null, null
        )
        val enrolled = cursor.moveToFirst()
        cursor.close()
        db.close()
        return enrolled
    }

    fun getEnrollmentsByClass(classId: String): List<StudentEnrollment> {
        val list = mutableListOf<StudentEnrollment>()
        val db = this.readableDatabase
        val cursor = db.query(
            TABLE_ENROLLMENTS, null,
            "$COL_ENROLL_CLASS_ID=?",
            arrayOf(classId),
            null, null, null
        )
        if (cursor.moveToFirst()) {
            do {
                list.add(
                    StudentEnrollment(
                        studentName = cursor.getString(cursor.getColumnIndexOrThrow(COL_ENROLL_STUDENT)),
                        classId = cursor.getString(cursor.getColumnIndexOrThrow(COL_ENROLL_CLASS_ID)),
                        section = cursor.getString(cursor.getColumnIndexOrThrow(COL_ENROLL_SECTION))
                    )
                )
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return list
    }

    fun getEnrollmentsByStudent(studentName: String): List<StudentEnrollment> {
        val list = mutableListOf<StudentEnrollment>()
        val db = this.readableDatabase
        val cursor = db.query(
            TABLE_ENROLLMENTS, null,
            "$COL_ENROLL_STUDENT=?",
            arrayOf(studentName),
            null, null, null
        )
        if (cursor.moveToFirst()) {
            do {
                list.add(
                    StudentEnrollment(
                        studentName = cursor.getString(cursor.getColumnIndexOrThrow(COL_ENROLL_STUDENT)),
                        classId = cursor.getString(cursor.getColumnIndexOrThrow(COL_ENROLL_CLASS_ID)),
                        section = cursor.getString(cursor.getColumnIndexOrThrow(COL_ENROLL_SECTION))
                    )
                )
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return list
    }
}
