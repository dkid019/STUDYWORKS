package com.example.myapp.studyworks

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.studyworks.R
import java.io.File

class MyClassesActivity : AppCompatActivity() {

    private lateinit var dynamicClassesContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_classes)

        dynamicClassesContainer = findViewById(R.id.dynamicClassesContainer)

        val btnAdd = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu = findViewById<ImageView>(R.id.btnMenu)

        val etSearch = findViewById<EditText>(R.id.etSearch)
        val imgSearch = findViewById<ImageView>(R.id.imgSearch)
        val imgFilter = findViewById<ImageView>(R.id.imgFilter)

        val imgFilipinoCard = findViewById<ImageView>(R.id.imgFilipinoCard)
        val imgMathCard = findViewById<ImageView>(R.id.imgMathCard)
        val imgPeCard = findViewById<ImageView>(R.id.imgPeCard)
        val imgEnglishCard = findViewById<ImageView>(R.id.imgEnglishCard)

        val tvFilipino = findViewById<TextView>(R.id.tvFilipino)
        val tvMath = findViewById<TextView>(R.id.tvMath)
        val tvPe = findViewById<TextView>(R.id.tvPe)
        val tvEnglish = findViewById<TextView>(R.id.tvEnglish)

        val btnAddClass = findViewById<LinearLayout>(R.id.btnAddClass)

        setupTopButtons(btnAdd, btnMenu, btnAddClass)
        setupSearch(etSearch, imgSearch, imgFilter)
        setupClassClicks(
            imgFilipinoCard, imgMathCard, imgPeCard, imgEnglishCard,
            tvFilipino, tvMath, tvPe, tvEnglish
        )
        setupBottomNavigation()
        loadDynamicClasses()
    }

    override fun onResume() {
        super.onResume()
        loadDynamicClasses()
    }

    /**
     * Inflates item_dynamic_class for every created class.
     *
     * Cover logic:
     *   • classData.coverImagePath is non-empty and the file exists
     *       → hide tvCoverName, show imgClassCard, load with Glide
     *   • otherwise
     *       → show tvCoverName with the class name, hide imgClassCard
     */
    private fun loadDynamicClasses() {
        dynamicClassesContainer.removeAllViews()
        val classes = DataManager.getClasses(this)

        for (classData in classes) {
            val cardView = layoutInflater.inflate(
                R.layout.item_dynamic_class, dynamicClassesContainer, false
            )

            val tvCoverName = cardView.findViewById<TextView>(R.id.tvCoverName)
            val imgClassCard = cardView.findViewById<ImageView>(R.id.imgClassCard)
            val tvName = cardView.findViewById<TextView>(R.id.tvClassName)
            val tvSection = cardView.findViewById<TextView>(R.id.tvClassSection)
            val btnEdit = cardView.findViewById<TextView>(R.id.btnEditClass)
            val btnDelete = cardView.findViewById<TextView>(R.id.btnDeleteClass)

            tvName.text = classData.className
            tvSection.text = classData.section

            val coverFile = if (classData.coverImagePath.isNotEmpty())
                File(classData.coverImagePath) else null

            if (coverFile != null && coverFile.exists()) {
                // ── Custom photo cover ──────────────────────────────────────
                tvCoverName.visibility = android.view.View.GONE
                imgClassCard.visibility = android.view.View.VISIBLE

                Glide.with(this)
                    .load(coverFile)
                    .centerCrop()
                    .placeholder(R.drawable.bg_subject_card)
                    .into(imgClassCard)
            } else {
                // ── Default: white background with large subject name ────────
                imgClassCard.visibility = android.view.View.GONE
                tvCoverName.visibility = android.view.View.VISIBLE
                tvCoverName.text = classData.className
                // White background is already set in XML; no color override needed
            }

            cardView.setOnClickListener {
                val intent = Intent(this, ClassDetailsActivity::class.java)
                intent.putExtra("class_id", classData.id)
                intent.putExtra("subject_name", classData.className)
                startActivity(intent)
            }

            // ── Edit button ─────────────────────────────────────────────────
            btnEdit.setOnClickListener {
                showEditClassDialog(classData)
            }

            // ── Delete button ───────────────────────────────────────────────
            btnDelete.setOnClickListener {
                AlertDialog.Builder(this)
                    .setTitle("Delete Class")
                    .setMessage("Are you sure you want to delete \"${classData.className}\"?")
                    .setPositiveButton("Delete") { _, _ ->
                        DataManager.deleteClass(this, classData.id)
                        loadDynamicClasses()
                        Toast.makeText(this, "\"${classData.className}\" deleted", Toast.LENGTH_SHORT).show()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }

            dynamicClassesContainer.addView(cardView)
        }
    }

    private fun showEditClassDialog(classData: ClassData) {
        val dialogView = layoutInflater.inflate(android.R.layout.simple_list_item_1, null)

        // Build a simple dialog with an EditText for class name and section
        val layout = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(48, 32, 48, 16)
        }

        val etName = EditText(this).apply {
            hint = "Class Name"
            setText(classData.className)
        }
        val etSection = EditText(this).apply {
            hint = "Section"
            setText(classData.section)
        }
        val etRoom = EditText(this).apply {
            hint = "Room Number"
            setText(classData.roomNumber)
        }

        layout.addView(etName)
        layout.addView(etSection)
        layout.addView(etRoom)

        AlertDialog.Builder(this)
            .setTitle("Edit Class")
            .setView(layout)
            .setPositiveButton("Save") { _, _ ->
                val newName = etName.text.toString().trim()
                val newSection = etSection.text.toString().trim()
                val newRoom = etRoom.text.toString().trim()

                if (newName.isEmpty()) {
                    Toast.makeText(this, "Class name cannot be empty", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                val updated = classData.copy(
                    className = newName,
                    section = newSection,
                    roomNumber = newRoom
                )
                DataManager.updateClass(this, updated)
                loadDynamicClasses()
                Toast.makeText(this, "Class updated", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun setupTopButtons(
        btnAdd: ImageView,
        btnMenu: ImageView,
        btnAddClass: LinearLayout
    ) {
        btnAdd.setOnClickListener {
            startActivity(Intent(this, Add::class.java))
        }

        btnAddClass.setOnClickListener {
            startActivity(Intent(this, Add::class.java))
        }

        btnMenu.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }
    }

    private fun setupSearch(
        etSearch: EditText,
        imgSearch: ImageView,
        imgFilter: ImageView
    ) {
        imgSearch.setOnClickListener {
            val query = etSearch.text.toString().trim()
            if (query.isEmpty()) {
                Toast.makeText(this, "Please enter a class name", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Searching: $query", Toast.LENGTH_SHORT).show()
            }
        }

        imgFilter.setOnClickListener {
            Toast.makeText(this, "Filter clicked", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupClassClicks(
        imgFilipinoCard: ImageView,
        imgMathCard: ImageView,
        imgPeCard: ImageView,
        imgEnglishCard: ImageView,
        tvFilipino: TextView,
        tvMath: TextView,
        tvPe: TextView,
        tvEnglish: TextView
    ) {
        imgFilipinoCard.setOnClickListener { openSubjectDetails("Filipino") }
        imgMathCard.setOnClickListener { openSubjectDetails("Mathematics") }
        imgPeCard.setOnClickListener { openSubjectDetails("Physical Education") }
        imgEnglishCard.setOnClickListener { openSubjectDetails("English") }

        tvFilipino.setOnClickListener { openSubjectDetails("Filipino") }
        tvMath.setOnClickListener { openSubjectDetails("Mathematics") }
        tvPe.setOnClickListener { openSubjectDetails("Physical Education") }
        tvEnglish.setOnClickListener { openSubjectDetails("English") }
    }

    private fun openSubjectDetails(subjectName: String) {
        val intent = Intent(this, ClassDetailsActivity::class.java)
        intent.putExtra("subject_name", subjectName)
        startActivity(intent)
    }

    private fun setupBottomNavigation() {
        findViewById<LinearLayout>(R.id.navHome).setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }

        findViewById<LinearLayout>(R.id.navClasses).setOnClickListener { }

        findViewById<LinearLayout>(R.id.navNotification).setOnClickListener {
            startActivity(Intent(this, Notification::class.java))
            finish()
        }
    }
}
