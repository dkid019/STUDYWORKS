package com.example.myapp.studyworks

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class HelpCenterContact : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_help_center_contact)

        val btnAdd = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu = findViewById<ImageView>(R.id.btnMenu)
        val btnBack = findViewById<ImageView>(R.id.btnBack)
        val etSearchHelp = findViewById<EditText>(R.id.etSearchHelp)

        val tabFaq = findViewById<TextView>(R.id.tabFaq)
        val tabContactUs = findViewById<TextView>(R.id.tabContactUs)

        val tvEmailValue = findViewById<TextView>(R.id.tvEmailValue)
        val tvInstagramValue = findViewById<TextView>(R.id.tvInstagramValue)
        val tvFacebookValue = findViewById<TextView>(R.id.tvFacebookValue)

        // ✅ NEW BUTTON FROM YOUR SIMPLE VERSION

        // 🔙 BACK
        btnBack.setOnClickListener {
            finish()
        }

        // 🔝 HEADER
        btnAdd.setOnClickListener {
            startActivity(Intent(this, Add::class.java))
        }

        btnMenu.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }

        // 🧭 TABS
        tabFaq.setOnClickListener {
            finish() // go back to FAQ screen
        }

        tabContactUs.setOnClickListener {
            Toast.makeText(this, "Contact Us selected", Toast.LENGTH_SHORT).show()
        }

        // 📧 CONTACT DETAILS
        tvEmailValue.setOnClickListener {
            Toast.makeText(this, "Email: ${tvEmailValue.text}", Toast.LENGTH_SHORT).show()
        }

        tvInstagramValue.setOnClickListener {
            Toast.makeText(this, "Instagram: ${tvInstagramValue.text}", Toast.LENGTH_SHORT).show()
        }

        tvFacebookValue.setOnClickListener {
            Toast.makeText(this, "Facebook: ${tvFacebookValue.text}", Toast.LENGTH_SHORT).show()
        }

        // 🔍 SEARCH
        etSearchHelp.setOnEditorActionListener { _, _, _ ->
            Toast.makeText(this, "Searching: ${etSearchHelp.text}", Toast.LENGTH_SHORT).show()
            true
        }

        // ✅ SIMPLE SEND LOGIC APPLIED

    }
}