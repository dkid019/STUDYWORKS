package com.example.myapp.studyworks

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.Editable
import android.text.InputFilter
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class StudentRecords : AppCompatActivity() {

    private lateinit var etSearch: EditText
    private lateinit var tableBody: LinearLayout
    private lateinit var tvStudentCount: TextView
    private lateinit var dbHelper: DatabaseHelper

    // classId passed from the previous screen; empty means "global"
    private var classId: String = ""

    // ─── Resolved key used for all DB operations ───────────────────────────────
    private val resolvedClassId: String
        get() = classId.ifEmpty { "global" }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_student_records)

        classId  = intent.getStringExtra("class_id") ?: ""
        dbHelper = DatabaseHelper(this)

        // Views
        val btnAdd    = findViewById<ImageView>(R.id.btnAdd)
        val btnBack   = findViewById<ImageView>(R.id.btnBack)
        val btnMenu   = findViewById<ImageView>(R.id.btnMenu)
        val btnFilter = findViewById<ImageView>(R.id.btnFilter)
        tvStudentCount = findViewById(R.id.tvStudentCount)
        etSearch       = findViewById(R.id.etSearch)
        tableBody      = findViewById(R.id.tableBody)

        // Buttons
        btnAdd.setOnClickListener    { showAddStudentDialog() }
        btnBack.setOnClickListener   { finish() }
        btnMenu.setOnClickListener   { Toast.makeText(this, "Menu", Toast.LENGTH_SHORT).show() }
        btnFilter.setOnClickListener { Toast.makeText(this, "Filter", Toast.LENGTH_SHORT).show() }

        // Live search
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                refresh(s?.toString()?.trim() ?: "")
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        // Bottom nav
        setupBottomNav()

        // Initial load
        refresh()
    }

    // ═══════════════════════════════════════════════════════════════
    //  ADD STUDENT DIALOG
    // ═══════════════════════════════════════════════════════════════
    private fun showAddStudentDialog() {

        // Build the form inside the dialog
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpToPx(24), dpToPx(16), dpToPx(24), dpToPx(8))
        }

        fun label(text: String) = TextView(this).apply {
            this.text      = text
            textSize       = 12f
            typeface       = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#666666"))
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dpToPx(12)
            layoutParams = lp
        }

        fun field(hint: String, caps: Int, maxLen: Int) = EditText(this).apply {
            this.hint       = hint
            textSize        = 14f
            maxLines        = 1
            inputType       = caps
            filters         = arrayOf(InputFilter.LengthFilter(maxLen))
            setTextColor(Color.parseColor("#111111"))
            setHintTextColor(Color.parseColor("#AAAAAA"))
            // Simple bottom-border style — safe on all API levels
            setBackgroundColor(Color.TRANSPARENT)
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dpToPx(4)
            layoutParams = lp
        }

        val nameField = field(
            "e.g. Juan dela Cruz",
            android.text.InputType.TYPE_CLASS_TEXT or
            android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS,
            60
        )
        val sectionField = field(
            "e.g. BSCS 3A",
            android.text.InputType.TYPE_CLASS_TEXT or
            android.text.InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS,
            30
        )

        container.addView(label("STUDENT NAME"))
        container.addView(nameField)
        container.addView(label("SECTION"))
        container.addView(sectionField)

        // Build dialog — set positive button listener MANUALLY so dialog
        // doesn't auto-dismiss on validation failure
        val dialog = AlertDialog.Builder(this)
            .setTitle("Add Student")
            .setView(container)
            .setPositiveButton("Save", null)
            .setNegativeButton("Cancel", null)
            .create()

        dialog.show()

        // Override Save click so we can validate before dismissing
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).apply {
            setTextColor(Color.parseColor("#2E7D32"))
            setOnClickListener {
                val name    = nameField.text.toString().trim()
                val section = sectionField.text.toString().trim()

                // ── Validate ──────────────────────────────────────────────────
                if (name.isEmpty()) {
                    nameField.error = "Name is required"
                    nameField.requestFocus()
                    return@setOnClickListener
                }
                if (section.isEmpty()) {
                    sectionField.error = "Section is required"
                    sectionField.requestFocus()
                    return@setOnClickListener
                }

                // ── Duplicate check (uses resolvedClassId consistently) ────────
                val alreadyExists = dbHelper
                    .getEnrollmentsByClass(resolvedClassId)
                    .any { it.studentName.equals(name, ignoreCase = true) }

                if (alreadyExists) {
                    nameField.error = "\"$name\" is already in the list"
                    nameField.requestFocus()
                    return@setOnClickListener
                }

                // ── Save to SQLite ────────────────────────────────────────────
                val enrollment = StudentEnrollment(
                    studentName = name,
                    classId     = resolvedClassId,
                    section     = section
                )
                dbHelper.addEnrollment(enrollment)

                Toast.makeText(this@StudentRecords, "✓ $name added", Toast.LENGTH_SHORT).show()
                dialog.dismiss()

                // Refresh table — keep whatever search query is active
                refresh(etSearch.text.toString().trim())
            }
        }

        dialog.getButton(AlertDialog.BUTTON_NEGATIVE)
            .setTextColor(Color.parseColor("#9E9E9E"))
    }

    // ═══════════════════════════════════════════════════════════════
    //  DATA REFRESH
    // ═══════════════════════════════════════════════════════════════
    private fun refresh(query: String = "") {
        // Always read from SQLite — no in-memory hardcoded data
        val allStudents = dbHelper.getEnrollmentsByClass(resolvedClassId)
            .map { StudentInfo(it.studentName, it.section, emptyList()) }

        val filtered = if (query.isEmpty()) {
            allStudents
        } else {
            val q = query.lowercase()
            allStudents.filter {
                it.name.lowercase().contains(q) ||
                it.section.lowercase().contains(q)
            }
        }

        // Update count pill
        tvStudentCount.text = when {
            query.isEmpty() -> "${allStudents.size} Student${if (allStudents.size != 1) "s" else ""}"
            else            -> "${filtered.size} of ${allStudents.size} Student${if (allStudents.size != 1) "s" else ""}"
        }

        renderRows(filtered)
    }

    // ═══════════════════════════════════════════════════════════════
    //  RENDER TABLE ROWS
    // ═══════════════════════════════════════════════════════════════
    private fun renderRows(list: List<StudentInfo>) {
        tableBody.removeAllViews()

        if (list.isEmpty()) {
            showEmptyState()
            return
        }

        list.forEachIndexed { index, student ->
            val isEven = index % 2 == 0
            val rowColor  = if (isEven) Color.parseColor("#FFFFFF") else Color.parseColor("#F7F9FC")
            val pressColor = Color.parseColor("#E8F5E9")

            // ── Row ──────────────────────────────────────────────────────────
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity     = Gravity.CENTER_VERTICAL
                setPadding(0, dpToPx(14), 0, dpToPx(14))
                minimumHeight = dpToPx(52)
                isClickable = true
                isFocusable = true
                setBackgroundColor(rowColor)
            }

            // Column #1 — row number
            val numView = TextView(this).apply {
                text      = "${index + 1}"
                textSize  = 12f
                gravity   = Gravity.CENTER
                setTextColor(Color.parseColor("#AAAAAA"))
                layoutParams = LinearLayout.LayoutParams(dpToPx(40), LinearLayout.LayoutParams.WRAP_CONTENT)
            }

            // Vertical separator
            val sep1 = verticalSep()

            // Column #2 — name (weight 3)
            val nameView = TextView(this).apply {
                text     = student.name
                textSize = 14f
                maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
                setTextColor(Color.parseColor("#111111"))
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 3f)
                lp.marginStart = dpToPx(12)
                lp.marginEnd   = dpToPx(4)
                layoutParams = lp
            }

            // Vertical separator
            val sep2 = verticalSep()

            // Column #3 — section (weight 2)
            val sectionView = TextView(this).apply {
                text      = student.section
                textSize  = 13f
                gravity   = Gravity.CENTER
                maxLines  = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                setTextColor(Color.parseColor("#444444"))
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 2f)
            }

            row.addView(numView)
            row.addView(sep1)
            row.addView(nameView)
            row.addView(sep2)
            row.addView(sectionView)

            // Tap → attendance screen
            row.setOnClickListener {
                row.setBackgroundColor(pressColor)
                row.postDelayed({ row.setBackgroundColor(rowColor) }, 160)
                startActivity(
                    Intent(this, StudentRecordsAttendance::class.java).apply {
                        putExtra("student_name",    student.name)
                        putExtra("student_section", student.section)
                    }
                )
            }

            // Long-press → remove
            row.setOnLongClickListener {
                AlertDialog.Builder(this)
                    .setTitle("Remove Student")
                    .setMessage("Remove \"${student.name}\" from records?")
                    .setPositiveButton("Remove") { _, _ ->
                        dbHelper.deleteEnrollment(student.name, resolvedClassId)
                        Toast.makeText(this, "${student.name} removed", Toast.LENGTH_SHORT).show()
                        refresh(etSearch.text.toString().trim())
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
                true
            }

            tableBody.addView(row)

            // Row divider
            if (index != list.lastIndex) {
                tableBody.addView(hDivider())
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  EMPTY STATE
    // ═══════════════════════════════════════════════════════════════
    private fun showEmptyState() {
        val wrapper = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity     = Gravity.CENTER
            setPadding(dpToPx(32), dpToPx(64), dpToPx(32), dpToPx(64))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        val icon = TextView(this).apply {
            text    = "👤"
            textSize = 44f
            gravity = Gravity.CENTER
        }
        val title = TextView(this).apply {
            text      = "No students yet"
            textSize  = 16f
            gravity   = Gravity.CENTER
            typeface  = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#555555"))
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dpToPx(8)
            layoutParams = lp
        }
        val sub = TextView(this).apply {
            text     = "Tap the  ＋  button at the top to add a student"
            textSize = 13f
            gravity  = Gravity.CENTER
            setTextColor(Color.parseColor("#9E9E9E"))
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dpToPx(6)
            layoutParams = lp
        }
        wrapper.addView(icon)
        wrapper.addView(title)
        wrapper.addView(sub)
        tableBody.addView(wrapper)
    }

    // ═══════════════════════════════════════════════════════════════
    //  HELPERS
    // ═══════════════════════════════════════════════════════════════

    /** Vertical separator for inside a horizontal row */
    private fun verticalSep(): View = View(this).apply {
        // Fixed height so it renders correctly inside wrap_content row
        layoutParams = LinearLayout.LayoutParams(dpToPx(1), dpToPx(28))
        setBackgroundColor(Color.parseColor("#E0E0E0"))
    }

    /** Horizontal divider between rows */
    private fun hDivider(): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 1
        )
        setBackgroundColor(Color.parseColor("#EEEEEE"))
    }

    private fun dpToPx(dp: Int): Int =
        (dp * resources.displayMetrics.density + 0.5f).toInt()

    // ═══════════════════════════════════════════════════════════════
    //  BOTTOM NAV
    // ═══════════════════════════════════════════════════════════════
    private fun setupBottomNav() {
        fun nav(id: Int, dest: Class<*>) =
            findViewById<LinearLayout>(id)?.setOnClickListener {
                startActivity(Intent(this, dest))
            }
        nav(R.id.navHome,         HomeActivity::class.java)
        nav(R.id.navClasses,      MyClassesActivity::class.java)
        nav(R.id.navNotification, Notification::class.java)
        nav(R.id.navProfile,      Profile::class.java)
        nav(R.id.navMore,         MoreActivity::class.java)
    }
}
