package com.example.myapp.studyworks

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.Switch
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class TrueOrFalse : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_true_or_false)

        val btnAdd = findViewById<ImageButton>(R.id.btnAdd)
        val btnMenu = findViewById<ImageButton>(R.id.btnMenu)
        val etSearch = findViewById<EditText>(R.id.etSearch)
        val imgFilter = findViewById<ImageView>(R.id.imgFilter)
        val btnClose = findViewById<ImageView>(R.id.btnClose)

        val switchRequired = findViewById<Switch>(R.id.switchRequired)
        val etQuestion = findViewById<EditText>(R.id.etQuestion)
        val btnTrue = findViewById<Button>(R.id.btnTrue)
        val btnFalse = findViewById<Button>(R.id.btnFalse)
        val btnAddAnswer = findViewById<Button>(R.id.btnAddAnswer)
        val btnUpload = findViewById<Button>(R.id.btnUpload)

        btnAdd.setOnClickListener {
            Toast.makeText(this, "Add clicked", Toast.LENGTH_SHORT).show()
        }

        btnMenu.setOnClickListener {
            Toast.makeText(this, "Menu clicked", Toast.LENGTH_SHORT).show()
        }

        imgFilter.setOnClickListener {
            Toast.makeText(this, "Filter clicked", Toast.LENGTH_SHORT).show()
        }

        btnClose.setOnClickListener {
            finish()
        }

        btnTrue.setOnClickListener {
            Toast.makeText(this, "TRUE selected", Toast.LENGTH_SHORT).show()
        }

        btnFalse.setOnClickListener {
            Toast.makeText(this, "FALSE selected", Toast.LENGTH_SHORT).show()
        }

        btnAddAnswer.setOnClickListener {
            Toast.makeText(this, "Add Answer clicked", Toast.LENGTH_SHORT).show()
        }

        btnUpload.setOnClickListener {
            val question = etQuestion.text.toString().trim()
            val required = switchRequired.isChecked

            if (question.isEmpty()) {
                etQuestion.error = "Please enter a question"
            } else {
                Toast.makeText(
                    this,
                    "Uploaded\nQuestion: $question\nRequired: $required",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }
}