package com.example.myapp.studyworks

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class MyClassesDoneActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_classes_done)

        val btnAdd = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu = findViewById<ImageView>(R.id.btnMenu)

        val etSearch = findViewById<EditText>(R.id.etSearch)
        val imgSearch = findViewById<ImageView>(R.id.imgSearch)
        val imgFilter = findViewById<ImageView>(R.id.imgFilter)
        val btnCalendar = findViewById<ImageView>(R.id.btnCalendar)

        val tabMaterials = findViewById<TextView>(R.id.tabMaterials)
        val tabTodo = findViewById<TextView>(R.id.tabTodo)
        val tabAnnouncement = findViewById<TextView>(R.id.tabAnnouncement)

        val dropdownAssigned = findViewById<LinearLayout>(R.id.dropdownAssigned)
        val dropdownMissing = findViewById<TextView>(R.id.dropdownMissing)
        val dropdownDone = findViewById<TextView>(R.id.dropdownDone)
        val tvStatus = findViewById<TextView>(R.id.tvStatus)

        val navHome = findViewById<LinearLayout>(R.id.navHome)
        val navClasses = findViewById<LinearLayout>(R.id.navClasses)
        val navNotification = findViewById<LinearLayout>(R.id.navNotification)

        btnAdd.setOnClickListener {
            startActivity(Intent(this, AddClassOrJoinActivity::class.java))
        }

        btnMenu.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }

        imgSearch.setOnClickListener {
            val query = etSearch.text.toString().trim()
            if (query.isEmpty()) {
                Toast.makeText(this, "Please enter a class name", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Searching: $query", Toast.LENGTH_SHORT).show()
            }
        }

        imgFilter.setOnClickListener {
            Toast.makeText(this, "Filter clicked", Toast.LENGTH_SHORT).show()
        }

        btnCalendar.setOnClickListener {
            Toast.makeText(this, "Calendar clicked", Toast.LENGTH_SHORT).show()
        }

        tabMaterials.setOnClickListener {
            startActivity(Intent(this, MyClassesActivity::class.java))
            finish()
        }

        tabTodo.setOnClickListener {
            Toast.makeText(this, "Already in TO DO", Toast.LENGTH_SHORT).show()
        }

        tabAnnouncement.setOnClickListener {
            startActivity(Intent(this, Announcements::class.java))
        }

        dropdownAssigned.setOnClickListener {
            tvStatus.text = "   Assigned"
            startActivity(Intent(this, MyClassesActivity::class.java))
            finish()
        }

        dropdownMissing.setOnClickListener {
            tvStatus.text = "Missing"
            startActivity(Intent(this, Missing::class.java))
            finish()
        }

        dropdownDone.setOnClickListener {
            tvStatus.text = "Done"
            Toast.makeText(this, "Already in Done", Toast.LENGTH_SHORT).show()
        }

        navHome.setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }

        navClasses.setOnClickListener {
            Toast.makeText(this, "Already in My Classes", Toast.LENGTH_SHORT).show()
        }

        navNotification.setOnClickListener {
            startActivity(Intent(this, Notification::class.java))
        }
    }
}