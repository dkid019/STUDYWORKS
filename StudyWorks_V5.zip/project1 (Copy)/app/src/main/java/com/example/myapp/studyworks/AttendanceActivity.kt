package com.example.myapp.studyworks

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.studyworks.R
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class AttendanceActivity : AppCompatActivity() {

    private var selectedStatus = "Present"
    private var selectedDate = ""
    private var classId = ""
    private var calendar = Calendar.getInstance()

    private lateinit var tvSelectedDate: TextView
    private lateinit var tvMonthYear: TextView
    private lateinit var calendarGrid: GridLayout
    private lateinit var optionPresent: LinearLayout
    private lateinit var optionAbsent: LinearLayout
    private lateinit var btnSubmit: Button
    
    private lateinit var imgPresent: ImageView
    private lateinit var imgAbsent: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_attendance)

        classId = intent.getStringExtra("class_id") ?: ""

        initViews()
        setupClicks()
        
        val now = Calendar.getInstance()
        calendar = now.clone() as Calendar
        val sdfData = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        selectedDate = sdfData.format(now.time)
        
        val sdfDate = SimpleDateFormat("EEE, MMM dd", Locale.getDefault())
        tvSelectedDate.text = sdfDate.format(now.time)
        
        updateCalendar()
        updateStatusUI()
    }

    private fun initViews() {
        tvSelectedDate = findViewById(R.id.tvSelectedDate)
        tvMonthYear = findViewById(R.id.tvMonthYear)
        calendarGrid = findViewById(R.id.calendarGrid)
        optionPresent = findViewById(R.id.optionPresent)
        optionAbsent = findViewById(R.id.optionAbsent)
        btnSubmit = findViewById(R.id.btnSubmit)
        imgPresent = findViewById(R.id.imgPresent)
        imgAbsent = findViewById(R.id.imgAbsent)
    }

    private fun setupClicks() {
        findViewById<ImageView>(R.id.btnEditDate).setOnClickListener { openDatePicker() }
        findViewById<TextView>(R.id.btnBack).setOnClickListener { finish() }
        
        findViewById<TextView>(R.id.btnPrevMonth).setOnClickListener {
            calendar.add(Calendar.MONTH, -1)
            updateCalendar()
        }
        
        findViewById<TextView>(R.id.btnNextMonth).setOnClickListener {
            calendar.add(Calendar.MONTH, 1)
            updateCalendar()
        }

        optionPresent.setOnClickListener {
            selectedStatus = "Present"
            updateStatusUI()
            updateCalendar() 
        }

        optionAbsent.setOnClickListener {
            selectedStatus = "Absent"
            updateStatusUI()
            updateCalendar() 
        }

        btnSubmit.setOnClickListener { submitAttendance() }
        
        setupBottomNavigation()
    }

    private fun updateCalendar() {
        val sdfMonthYear = SimpleDateFormat("MMMM yyyy", Locale.getDefault())
        tvMonthYear.text = sdfMonthYear.format(calendar.time)

        calendarGrid.removeAllViews()

        val tempCalendar = calendar.clone() as Calendar
        tempCalendar.set(Calendar.DAY_OF_MONTH, 1)
        
        val firstDayOfWeek = tempCalendar.get(Calendar.DAY_OF_WEEK) - 1
        val daysInMonth = tempCalendar.getActualMaximum(Calendar.DAY_OF_MONTH)

        for (i in 0 until firstDayOfWeek) {
            val emptyView = TextView(this)
            emptyView.layoutParams = createGridLayoutParams()
            calendarGrid.addView(emptyView)
        }

        val sdfData = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

        for (day in 1..daysInMonth) {
            val dayView = TextView(this)
            dayView.text = day.toString()
            dayView.gravity = Gravity.CENTER
            dayView.layoutParams = createGridLayoutParams()
            dayView.textSize = 14f
            dayView.setTextColor(ContextCompat.getColor(this, android.R.color.black))
            
            val checkCalendar = calendar.clone() as Calendar
            checkCalendar.set(Calendar.DAY_OF_MONTH, day)
            val dayString = sdfData.format(checkCalendar.time)
            
            if (dayString == selectedDate) {
                // Highlight with selected status color
                if (selectedStatus == "Present") {
                    dayView.setBackgroundResource(R.drawable.bg_present_day)
                } else {
                    dayView.setBackgroundResource(R.drawable.bg_absent_day)
                }
                dayView.setTextColor(ContextCompat.getColor(this, android.R.color.white))
            }

            dayView.setOnClickListener {
                selectedDate = dayString
                val sdfSelected = SimpleDateFormat("EEE, MMM dd", Locale.getDefault())
                tvSelectedDate.text = sdfSelected.format(checkCalendar.time)
                updateCalendar() 
            }
            
            calendarGrid.addView(dayView)
        }
    }

    private fun createGridLayoutParams(): GridLayout.LayoutParams {
        val params = GridLayout.LayoutParams()
        params.width = 0
        params.height = (40 * resources.displayMetrics.density).toInt()
        params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
        params.setMargins(2, 2, 2, 2)
        return params
    }

    private fun openDatePicker() {
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        DatePickerDialog(this, { _, y, m, d ->
            calendar.set(y, m, d)
            val sdfDate = SimpleDateFormat("EEE, MMM dd", Locale.getDefault())
            val sdfData = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            selectedDate = sdfData.format(calendar.time)
            tvSelectedDate.text = sdfDate.format(calendar.time)
            updateCalendar()
        }, year, month, day).show()
    }

    private fun updateStatusUI() {
        if (selectedStatus == "Present") {
            optionPresent.setBackgroundResource(R.drawable.bg_round_icon_green)
            optionAbsent.setBackgroundResource(0)
            imgPresent.setColorFilter(ContextCompat.getColor(this, android.R.color.white))
            imgAbsent.setColorFilter(ContextCompat.getColor(this, android.R.color.black))
        } else {
            optionPresent.setBackgroundResource(0)
            optionAbsent.setBackgroundResource(R.drawable.bg_absent_day)
            imgPresent.setColorFilter(ContextCompat.getColor(this, android.R.color.black))
            imgAbsent.setColorFilter(ContextCompat.getColor(this, android.R.color.white))
        }
    }

    private fun submitAttendance() {
        if (selectedDate.isEmpty()) {
            Toast.makeText(this, "Please select a date", Toast.LENGTH_SHORT).show()
            return
        }

        val attendance = AttendanceData(
            classId = classId,
            studentName = "Current User",
            date = selectedDate,
            status = selectedStatus
        )

        DataManager.addAttendance(attendance)
        Toast.makeText(this, "Attendance submitted for $selectedDate", Toast.LENGTH_SHORT).show()
        finish()
    }

    private fun setupBottomNavigation() {
        findViewById<LinearLayout>(R.id.navHome)?.setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }
        findViewById<LinearLayout>(R.id.navClasses)?.setOnClickListener {
            startActivity(Intent(this, MyClassesActivity::class.java))
            finish()
        }
        findViewById<LinearLayout>(R.id.navNotification)?.setOnClickListener {
            startActivity(Intent(this, Notification::class.java))
            finish()
        }
    }
}
