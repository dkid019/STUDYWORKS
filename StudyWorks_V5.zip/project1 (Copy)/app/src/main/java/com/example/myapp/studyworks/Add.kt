package com.example.myapp.studyworks

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class Add : AppCompatActivity() {

    private lateinit var imgLogo: ImageView
    private lateinit var btnAdd: ImageView
    private lateinit var btnMenu: ImageView

    private lateinit var btnCreateClass: LinearLayout
    private lateinit var btnJoinClass: LinearLayout
    private lateinit var btnUploadMaterial: LinearLayout
    private lateinit var btnCreateQuiz: LinearLayout
    private lateinit var btnAddAnnouncement: LinearLayout
    private lateinit var btnAddTodo: LinearLayout
    private lateinit var btnBack: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_options)

        initViews()
        setupClicks()
    }

    private fun initViews() {
        imgLogo = findViewById(R.id.imgLogo)
        btnAdd = findViewById(R.id.btnAdd)
        btnMenu = findViewById(R.id.btnMenu)

        btnCreateClass = findViewById(R.id.btnCreateClass)
        btnJoinClass = findViewById(R.id.btnJoinClass)
        btnUploadMaterial = findViewById(R.id.btnUploadMaterial)
        btnCreateQuiz = findViewById(R.id.btnCreateQuiz)
        btnAddAnnouncement = findViewById(R.id.btnAddAnnouncement)
        btnAddTodo = findViewById(R.id.btnAddTodo)
        btnBack = findViewById(R.id.btnBack)
    }

    private fun setupClicks() {
        btnAdd.setOnClickListener {
            Toast.makeText(this, "You are already on Add screen", Toast.LENGTH_SHORT).show()
        }

        btnMenu.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }

        btnBack.setOnClickListener {
            finish()
        }

        btnCreateClass.setOnClickListener {
            startActivity(Intent(this, CreateClassActivity::class.java))
        }

        btnJoinClass.setOnClickListener {
            startActivity(Intent(this, JoinClass::class.java))
        }

        btnUploadMaterial.setOnClickListener {
            startActivity(Intent(this, UploadMaterialActivity::class.java))
        }

        btnCreateQuiz.setOnClickListener {
            startActivity(Intent(this, CreateQuiz::class.java))
        }

        btnAddAnnouncement.setOnClickListener {
            val intent = Intent(this, EditAnnouncementActivity::class.java)
            intent.putExtra("is_new", true)
            startActivity(intent)
        }

        btnAddTodo.setOnClickListener {
            startActivity(Intent(this, AddTodoActivity::class.java))
        }

        findViewById<LinearLayout>(R.id.navHome)?.setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }

        findViewById<LinearLayout>(R.id.navClasses)?.setOnClickListener {
            startActivity(Intent(this, MyClassesActivity::class.java))
            finish()
        }

        findViewById<LinearLayout>(R.id.navNotification)?.setOnClickListener {
            startActivity(Intent(this, Notification::class.java))
            finish()
        }
    }
}
