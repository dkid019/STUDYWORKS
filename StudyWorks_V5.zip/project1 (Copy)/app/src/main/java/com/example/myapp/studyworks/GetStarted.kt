package com.example.myapp.studyworks

import android.content.Intent
import android.os.Bundle
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class GetStarted : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_get_started)

        val btnGetStarted = findViewById<LinearLayout>(R.id.btnGetStarted)

        btnGetStarted.setOnClickListener {
            startActivity(Intent(this, Login::class.java))
            finish()
        }
    }
}