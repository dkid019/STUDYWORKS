package com.example.myapp.studyworks

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class Login : AppCompatActivity() {

    private var isPasswordVisible = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val etUsername = findViewById<EditText>(R.id.etUsername)
        val etPasswordMain = findViewById<EditText>(R.id.etPassword)
        val cbRemember = findViewById<CheckBox>(R.id.cbRemember)
        val btnLogin = findViewById<Button>(R.id.btnLogin)
        val tvSignUp = findViewById<TextView>(R.id.btnSignup)
        val imgBack = findViewById<ImageView>(R.id.btnBack)
        val imgEye = findViewById<ImageView>(R.id.imgEye)
        val tvForgotPassword = findViewById<TextView>(R.id.tvForgotPassword)

        val sharedPref = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
        val isRemembered = sharedPref.getBoolean("RememberMe", false)
        
        if (isRemembered) {
            val lastUser = sharedPref.getString("LastUsername", "")
            etUsername.setText(lastUser)
            cbRemember.isChecked = true
        }

        btnLogin.setOnClickListener {
            val username = etUsername.text.toString().trim()
            val password = etPasswordMain.text.toString().trim()

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Updated to pass 'this' context for Database access
            val user = DataManager.loginUser(this, username, password)

            if (user != null) {
                with(sharedPref.edit()) {
                    if (cbRemember.isChecked) {
                        putBoolean("RememberMe", true)
                        putString("LastUsername", username)
                    } else {
                        putBoolean("RememberMe", false)
                        putString("LastUsername", "")
                    }
                    apply()
                }

                Toast.makeText(this, "Welcome, ${user.firstName}!", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this, HomeActivity::class.java))
                finish()
            } else {
                Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show()
            }
        }

        tvSignUp.setOnClickListener {
            startActivity(Intent(this, SignUp::class.java))
        }

        imgBack.setOnClickListener {
            finish()
        }

        imgEye.setOnClickListener {
            if (isPasswordVisible) {
                etPasswordMain.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                imgEye.setImageResource(R.drawable.ic_eye_off)
            } else {
                etPasswordMain.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                imgEye.setImageResource(R.drawable.ic_eye_off) // Using ic_eye_off for both as it's the only one found
            }
            etPasswordMain.setSelection(etPasswordMain.text.length)
            isPasswordVisible = !isPasswordVisible
        }

        tvForgotPassword.setOnClickListener {
            Toast.makeText(this, "Redirecting to help center...", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this, HelpCenterForgotPassword::class.java))
        }
    }
}