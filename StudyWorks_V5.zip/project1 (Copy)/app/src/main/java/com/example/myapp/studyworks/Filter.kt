package com.example.myapp.studyworks

import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class Filter : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_filter)

        val btnAdd = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu = findViewById<ImageView>(R.id.btnMenu)
        val btnFilter = findViewById<ImageView>(R.id.btnFilter)
        val etSearch = findViewById<EditText>(R.id.etSearch)
        val btnApply = findViewById<Button>(R.id.btnApply)

        val cbFilipino = findViewById<CheckBox>(R.id.cbFilipino)
        val cbEnglish = findViewById<CheckBox>(R.id.cbEnglish)
        val cbPE = findViewById<CheckBox>(R.id.cbPE)
        val cbMath = findViewById<CheckBox>(R.id.cbMath)

        val cbPdf = findViewById<CheckBox>(R.id.cbPdf)
        val cbPpt = findViewById<CheckBox>(R.id.cbPpt)
        val cbDoc = findViewById<CheckBox>(R.id.cbDoc)
        val cbVideo = findViewById<CheckBox>(R.id.cbVideo)

        val cbAZ = findViewById<CheckBox>(R.id.cbAZ)
        val cbHighToLow = findViewById<CheckBox>(R.id.cbHighToLow)
        val cbLowToHigh = findViewById<CheckBox>(R.id.cbLowToHigh)

        val cbNewest = findViewById<CheckBox>(R.id.cbNewest)
        val cbOldest = findViewById<CheckBox>(R.id.cbOldest)

        btnAdd.setOnClickListener {
            Toast.makeText(this, "Add clicked", Toast.LENGTH_SHORT).show()
        }

        btnMenu.setOnClickListener {
            Toast.makeText(this, "Menu clicked", Toast.LENGTH_SHORT).show()
        }

        btnFilter.setOnClickListener {
            Toast.makeText(this, "Filter clicked", Toast.LENGTH_SHORT).show()
        }

        etSearch.setOnEditorActionListener { _, _, _ ->
            Toast.makeText(this, "Searching: ${etSearch.text}", Toast.LENGTH_SHORT).show()
            true
        }

        btnApply.setOnClickListener {
            val selected = mutableListOf<String>()

            if (cbFilipino.isChecked) selected.add("Filipino")
            if (cbEnglish.isChecked) selected.add("English")
            if (cbPE.isChecked) selected.add("Physical Education")
            if (cbMath.isChecked) selected.add("Mathematics")

            if (cbPdf.isChecked) selected.add("PDF")
            if (cbPpt.isChecked) selected.add("PPT")
            if (cbDoc.isChecked) selected.add("Doc")
            if (cbVideo.isChecked) selected.add("Video")

            if (cbAZ.isChecked) selected.add("A-Z")
            if (cbHighToLow.isChecked) selected.add("Highest to Lowest")
            if (cbLowToHigh.isChecked) selected.add("Lowest to Highest")

            if (cbNewest.isChecked) selected.add("Newest")
            if (cbOldest.isChecked) selected.add("Oldest")

            val message = if (selected.isEmpty()) {
                "No filters selected"
            } else {
                "Selected: ${selected.joinToString()}"
            }

            Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        }
    }
}