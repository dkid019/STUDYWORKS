package com.example.myapp.studyworks

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class CreateQuiz : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_quiz)

        val question = findViewById<EditText>(R.id.etQuestion)

        val opt1 = findViewById<EditText>(R.id.option1)
        val opt2 = findViewById<EditText>(R.id.option2)
        val opt3 = findViewById<EditText>(R.id.option3)
        val opt4 = findViewById<EditText>(R.id.option4)

        val btnCorrectAnswer = findViewById<Button>(R.id.btnCorrectAnswer)
        val btnSaveQuiz = findViewById<Button>(R.id.btnUpload)
        val btnBack = findViewById<ImageButton>(R.id.btnClose)

        var correctAnswer = "Option 1"

        btnCorrectAnswer.setOnClickListener {
            correctAnswer = when (correctAnswer) {
                "Option 1" -> "Option 2"
                "Option 2" -> "Option 3"
                "Option 3" -> "Option 4"
                else -> "Option 1"
            }
            btnCorrectAnswer.text = correctAnswer
        }

        btnBack.setOnClickListener {
            finish()
        }

        btnSaveQuiz.setOnClickListener {
            val quizQuestion = question.text.toString().trim()
            val answer1 = opt1.text.toString().trim()
            val answer2 = opt2.text.toString().trim()
            val answer3 = opt3.text.toString().trim()
            val answer4 = opt4.text.toString().trim()

            if (
                quizQuestion.isEmpty() ||
                answer1.isEmpty() ||
                answer2.isEmpty() ||
                answer3.isEmpty() ||
                answer4.isEmpty()
            ) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Quiz created", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }
}