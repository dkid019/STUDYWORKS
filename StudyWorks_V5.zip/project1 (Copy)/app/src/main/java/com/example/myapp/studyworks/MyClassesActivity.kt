package com.example.myapp.studyworks

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.studyworks.R
import java.io.File

class MyClassesActivity : AppCompatActivity() {

    private lateinit var dynamicClassesContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_classes)

        dynamicClassesContainer = findViewById(R.id.dynamicClassesContainer)

        val btnAdd = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu = findViewById<ImageView>(R.id.btnMenu)

        val etSearch = findViewById<EditText>(R.id.etSearch)
        val imgSearch = findViewById<ImageView>(R.id.imgSearch)
        val imgFilter = findViewById<ImageView>(R.id.imgFilter)

        val btnAddClass = findViewById<LinearLayout>(R.id.btnAddClass)

        setupTopButtons(btnAdd, btnMenu, btnAddClass)
        setupSearch(etSearch, imgSearch, imgFilter)
        setupBottomNavigation()
        loadDynamicClasses()
    }

    override fun onResume() {
        super.onResume()
        loadDynamicClasses()
    }

    /**
     * Inflates item_dynamic_class for every created class.
     *
     * Cover logic:
     *   • classData.coverImagePath is non-empty and the file exists
     *       → hide tvCoverName, show imgClassCard, load with Glide
     *   • otherwise
     *       → show tvCoverName with WHITE bg + BLACK text (bigger), black border via bg_subject_card_empty
     */
    private fun loadDynamicClasses() {
        dynamicClassesContainer.removeAllViews()
        val classes = DataManager.getClasses(this)

        if (classes.isEmpty()) {
            val emptyTv = TextView(this).apply {
                text = "No classes yet. Tap + to create one."
                textSize = 13f
                setPadding(0, 16, 0, 16)
                setTextColor(resources.getColor(android.R.color.darker_gray, null))
            }
            dynamicClassesContainer.addView(emptyTv)
            return
        }

        for (classData in classes) {
            val cardView = layoutInflater.inflate(
                R.layout.item_dynamic_class, dynamicClassesContainer, false
            )

            val tvCoverName = cardView.findViewById<TextView>(R.id.tvCoverName)
            val imgClassCard = cardView.findViewById<ImageView>(R.id.imgClassCard)
            val tvName = cardView.findViewById<TextView>(R.id.tvClassName)
            val tvSection = cardView.findViewById<TextView>(R.id.tvClassSection)
            val btnEdit = cardView.findViewById<TextView>(R.id.btnEditClass)
            val btnDelete = cardView.findViewById<TextView>(R.id.btnDeleteClass)

            tvName.text = classData.className
            tvSection.text = classData.section

            val coverFile = if (classData.coverImagePath.isNotEmpty())
                File(classData.coverImagePath) else null

            if (coverFile != null && coverFile.exists()) {
                // ── Custom photo cover ──────────────────────────────────────
                tvCoverName.visibility = android.view.View.GONE
                imgClassCard.visibility = android.view.View.VISIBLE

                Glide.with(this)
                    .load(coverFile)
                    .centerCrop()
                    .placeholder(R.drawable.bg_subject_card)
                    .into(imgClassCard)
            } else {
                // ── Default: white bg + black text + black border ────────────
                imgClassCard.visibility = android.view.View.GONE
                tvCoverName.visibility = android.view.View.VISIBLE
                tvCoverName.text = classData.className
                // bg_subject_card_empty gives white bg + black border (set in XML)
            }

            // Card click → open details
            cardView.setOnClickListener {
                val intent = Intent(this, ClassDetailsActivity::class.java)
                intent.putExtra("class_id", classData.id)
                intent.putExtra("subject_name", classData.className)
                startActivity(intent)
            }

            // Edit button
            btnEdit.setOnClickListener {
                val intent = Intent(this, CreateClassActivity::class.java)
                intent.putExtra("edit_mode", true)
                intent.putExtra("class_id", classData.id)
                startActivity(intent)
            }

            // Delete button
            btnDelete.setOnClickListener {
                showDeleteConfirmation(classData)
            }

            dynamicClassesContainer.addView(cardView)
        }
    }

    private fun showDeleteConfirmation(classData: ClassData) {
        AlertDialog.Builder(this)
            .setTitle("Delete Class")
            .setMessage("Are you sure you want to delete \"${classData.className}\"? This cannot be undone.")
            .setPositiveButton("Delete") { _, _ ->
                DataManager.deleteClass(this, classData.id)
                Toast.makeText(this, "\"${classData.className}\" deleted.", Toast.LENGTH_SHORT).show()
                loadDynamicClasses()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun setupTopButtons(
        btnAdd: ImageView,
        btnMenu: ImageView,
        btnAddClass: LinearLayout
    ) {
        btnAdd.setOnClickListener {
            startActivity(Intent(this, Add::class.java))
        }

        btnAddClass.setOnClickListener {
            startActivity(Intent(this, Add::class.java))
        }

        btnMenu.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }
    }

    private fun setupSearch(
        etSearch: EditText,
        imgSearch: ImageView,
        imgFilter: ImageView
    ) {
        imgSearch.setOnClickListener {
            val query = etSearch.text.toString().trim()
            if (query.isEmpty()) {
                Toast.makeText(this, "Please enter a class name", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Searching: $query", Toast.LENGTH_SHORT).show()
            }
        }

        imgFilter.setOnClickListener {
            Toast.makeText(this, "Filter clicked", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupBottomNavigation() {
        findViewById<LinearLayout>(R.id.navHome).setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }

        findViewById<LinearLayout>(R.id.navClasses).setOnClickListener { }

        findViewById<LinearLayout>(R.id.navNotification).setOnClickListener {
            startActivity(Intent(this, Notification::class.java))
            finish()
        }
    }
}
