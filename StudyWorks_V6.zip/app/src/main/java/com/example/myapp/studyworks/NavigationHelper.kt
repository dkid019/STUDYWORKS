package com.example.myapp.studyworks

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.example.studyworks.R

object NavigationHelper {

    enum class Tab {
        HOME, CLASSES, NOTIFICATION, NONE
    }

    fun setupBottomNavigation(activity: Activity, activeTab: Tab) {
        val navHome = activity.findViewById<LinearLayout>(R.id.navHome)
        val navClasses = activity.findViewById<LinearLayout>(R.id.navClasses)
        val navNotification = activity.findViewById<LinearLayout>(R.id.navNotification)

        // Set active tab style
        when (activeTab) {
            Tab.HOME -> setActiveStyle(activity, R.id.ivNavHome, R.id.tvNavHome)
            Tab.CLASSES -> setActiveStyle(activity, R.id.ivNavClasses, R.id.tvNavClasses)
            Tab.NOTIFICATION -> setActiveStyle(activity, R.id.ivNavNotification, R.id.tvNavNotification)
            Tab.NONE -> { /* All inactive */ }
        }

        navHome?.setOnClickListener {
            if (activeTab != Tab.HOME) {
                val intent = Intent(activity, HomeActivity::class.java)
                activity.startActivity(intent)
                if (activeTab != Tab.NONE) activity.finish()
            }
        }

        navClasses?.setOnClickListener {
            if (activeTab != Tab.CLASSES) {
                val intent = Intent(activity, MyClassesActivity::class.java)
                activity.startActivity(intent)
                if (activeTab != Tab.NONE) activity.finish()
            }
        }

        navNotification?.setOnClickListener {
            if (activeTab != Tab.NOTIFICATION) {
                val intent = Intent(activity, Notification::class.java)
                activity.startActivity(intent)
                if (activeTab != Tab.NONE) activity.finish()
            }
        }
    }

    private fun setActiveStyle(activity: Activity, iconId: Int, textId: Int) {
        val icon = activity.findViewById<ImageView>(iconId)
        val text = activity.findViewById<TextView>(textId)
        val activeColor = ContextCompat.getColor(activity, R.color.active_tab_color) // Should define this in colors.xml or use hardcoded

        icon?.setColorFilter(ContextCompat.getColor(activity, R.color.active_tab_color))
        text?.setTextColor(ContextCompat.getColor(activity, R.color.active_tab_color))
        text?.setTypeface(null, Typeface.BOLD)
    }
}
