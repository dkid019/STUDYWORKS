package com.example.myapp.studyworks

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.example.studyworks.R
import java.io.File

class HomeActivity : AppCompatActivity() {

    private lateinit var dynamicClassesContainer: LinearLayout
    private lateinit var todoContainer: LinearLayout
    private lateinit var announcementContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        dynamicClassesContainer = findViewById(R.id.dynamicClassesContainer)
        todoContainer = findViewById(R.id.todoContainer)
        announcementContainer = findViewById(R.id.announcementContainer)

        val imgSearch = findViewById<ImageView>(R.id.imgSearch)
        val imgMenu = findViewById<ImageView>(R.id.imgMenu)
        val tvViewAll = findViewById<TextView>(R.id.tvViewAll)

        imgSearch.setOnClickListener {
            Toast.makeText(this, "Search clicked", Toast.LENGTH_SHORT).show()
        }

        imgMenu.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }

        tvViewAll.setOnClickListener {
            startActivity(Intent(this, MyClassesActivity::class.java))
        }

        NavigationHelper.setupBottomNavigation(this, NavigationHelper.Tab.HOME)

        loadDynamicClasses()
        loadTodos()
        loadAnnouncements()
    }

    override fun onResume() {
        super.onResume()
        loadDynamicClasses()
        loadTodos()
        loadAnnouncements()
    }

    private fun loadDynamicClasses() {
        dynamicClassesContainer.removeAllViews()
        val classes = DataManager.getClasses(this)

        if (classes.isNotEmpty()) {
            val titleView = TextView(this).apply {
                text = "My Classes"
                textSize = 16f
                setTypeface(null, Typeface.BOLD)
                setTextColor(ContextCompat.getColor(this@HomeActivity, android.R.color.black))
                setPadding(0, 16, 0, 12)
            }
            dynamicClassesContainer.addView(titleView)

            for (i in classes.indices step 2) {
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply { setMargins(0, 0, 0, 10) }
                }

                row.addView(createClassCard(classes[i]))

                val spacer = View(this).apply {
                    layoutParams = LinearLayout.LayoutParams(
                        (20 * resources.displayMetrics.density).toInt(),
                        1
                    )
                }
                row.addView(spacer)

                if (i + 1 < classes.size) {
                    row.addView(createClassCard(classes[i + 1]))
                } else {
                    val invisibleCard = View(this).apply {
                        layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
                    }
                    row.addView(invisibleCard)
                }

                dynamicClassesContainer.addView(row)
            }
        }
    }

    /**
     * Builds a class card View with cover logic:
     *   • cover photo exists  → show image via Glide
     *   • no cover photo      → white background + black text (bigger) + black border
     */
    private fun createClassCard(classData: ClassData): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setPadding(0, 0, 0, 16)
        }

        val coverHeightPx = (78 * resources.displayMetrics.density).toInt()

        val coverFrame = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                coverHeightPx
            )
            setBackgroundResource(R.drawable.bg_subject_card_empty)
            clipToOutline = true
        }

        // Layer 1: text cover (white bg + black text, shown when no photo)
        val tvCover = TextView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            text = classData.className
            textSize = 18f
            setTypeface(null, Typeface.BOLD)
            setTextColor(android.graphics.Color.BLACK)
            gravity = Gravity.CENTER
            setPadding(8, 8, 8, 8)
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
            setBackgroundResource(R.drawable.bg_subject_card_empty)
        }

        // Layer 2: photo cover (GONE until loaded)
        val imgCover = ImageView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            scaleType = ImageView.ScaleType.CENTER_CROP
            visibility = View.GONE
        }

        coverFrame.addView(tvCover)
        coverFrame.addView(imgCover)

        val coverFile = if (classData.coverImagePath.isNotEmpty())
            File(classData.coverImagePath) else null

        if (coverFile != null && coverFile.exists()) {
            tvCover.visibility = View.GONE
            imgCover.visibility = View.VISIBLE
            Glide.with(this)
                .load(coverFile)
                .centerCrop()
                .placeholder(R.drawable.bg_subject_card)
                .into(imgCover)
        }

        val textView = TextView(this).apply {
            text = classData.className
            textSize = 13f
            setTextColor(ContextCompat.getColor(this@HomeActivity, android.R.color.black))
            setPadding(0, 6, 0, 0)
        }

        card.addView(coverFrame)
        card.addView(textView)

        card.setOnClickListener {
            val intent = Intent(this, ClassDetailsActivity::class.java)
            intent.putExtra("class_id", classData.id)
            intent.putExtra("subject_name", classData.className)
            startActivity(intent)
        }

        return card
    }

    private fun loadTodos() {
        todoContainer.removeAllViews()
        val todos = DataManager.getTodos()

        if (todos.isEmpty()) {
            val emptyTv = TextView(this).apply {
                text = "No pending tasks"
                textSize = 12f
                setPadding(8, 8, 8, 8)
            }
            todoContainer.addView(emptyTv)
        } else {
            todos.forEach { todo ->
                val todoView = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(8, 8, 8, 8)
                    setBackgroundResource(R.drawable.bg_white_strip)
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply { setMargins(0, 0, 0, 8) }
                }

                val titleTv = TextView(this).apply {
                    text = todo.title
                    textSize = 13f
                    setTypeface(null, Typeface.BOLD)
                    setTextColor(ContextCompat.getColor(this@HomeActivity, android.R.color.black))
                }

                val dateTv = TextView(this).apply {
                    text = todo.dueDate
                    textSize = 11f
                    setTextColor(ContextCompat.getColor(this@HomeActivity, android.R.color.darker_gray))
                }

                todoView.addView(titleTv)
                todoView.addView(dateTv)
                todoContainer.addView(todoView)
            }
        }
    }

    private fun loadAnnouncements() {
        announcementContainer.removeAllViews()
        val announcements = DataManager.getAllAnnouncements()

        if (announcements.isEmpty()) {
            val emptyTv = TextView(this).apply {
                text = "No announcements"
                textSize = 12f
                setPadding(8, 8, 8, 8)
            }
            announcementContainer.addView(emptyTv)
        } else {
            announcements.forEach { announcement ->
                val annView = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(8, 8, 8, 8)
                    setBackgroundResource(R.drawable.bg_white_strip)
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply { setMargins(0, 0, 0, 8) }
                }

                val titleTv = TextView(this).apply {
                    text = announcement.title
                    textSize = 13f
                    setTypeface(null, Typeface.BOLD)
                    maxLines = 1
                    setTextColor(ContextCompat.getColor(this@HomeActivity, android.R.color.black))
                }

                val descTv = TextView(this).apply {
                    text = announcement.description
                    textSize = 11f
                    maxLines = 2
                    setTextColor(ContextCompat.getColor(this@HomeActivity, android.R.color.darker_gray))
                }

                annView.addView(titleTv)
                annView.addView(descTv)

                annView.setOnClickListener {
                    val intent = Intent(this, AnnouncementActivity::class.java)
                    intent.putExtra("announcement_id", announcement.id)
                    startActivity(intent)
                }

                announcementContainer.addView(annView)
            }
        }
    }


}
