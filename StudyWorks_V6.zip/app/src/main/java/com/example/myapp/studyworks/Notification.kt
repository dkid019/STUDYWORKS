package com.example.myapp.studyworks

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class Notification : AppCompatActivity() {

    private lateinit var notificationContainer: LinearLayout
    private lateinit var tvNoNotifications: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notification)

        notificationContainer = findViewById(R.id.notificationContainer)
        tvNoNotifications = findViewById(R.id.tvNoNotifications)

        val btnAdd = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu = findViewById<ImageView>(R.id.btnMenu)
        val btnFilter = findViewById<ImageView>(R.id.btnFilter)
        val etSearch = findViewById<EditText>(R.id.etSearch)
        val tvMarkAllRead = findViewById<TextView>(R.id.tvMarkAllRead)

        btnAdd.setOnClickListener {
            startActivity(Intent(this, Add::class.java))
        }

        btnMenu.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }

        btnFilter.setOnClickListener {
            Toast.makeText(this, "Filter clicked", Toast.LENGTH_SHORT).show()
        }

        tvMarkAllRead.setOnClickListener {
            Toast.makeText(this, "All notifications marked as read", Toast.LENGTH_SHORT).show()
        }

        etSearch.setOnEditorActionListener { _, _, _ ->
            Toast.makeText(this, "Searching: ${etSearch.text}", Toast.LENGTH_SHORT).show()
            true
        }

        NavigationHelper.setupBottomNavigation(this, NavigationHelper.Tab.NOTIFICATION)
        loadNotifications()
    }

    override fun onResume() {
        super.onResume()
        loadNotifications()
    }

    private fun loadNotifications() {
        notificationContainer.removeAllViews()
        val notifications = DataManager.getNotifications(this)

        if (notifications.isEmpty()) {
            tvNoNotifications.visibility = View.VISIBLE
        } else {
            tvNoNotifications.visibility = View.GONE
            for (notif in notifications) {
                // Check if R.layout.item_notification exists before inflating
                val notifView = try {
                    layoutInflater.inflate(R.layout.item_notification, notificationContainer, false)
                } catch (e: Exception) {
                    null
                }
                
                if (notifView != null) {
                    val imgIcon = notifView.findViewById<ImageView>(R.id.imgNotifIcon)
                    val tvTitle = notifView.findViewById<TextView>(R.id.tvNotifTitle)
                    val tvDesc = notifView.findViewById<TextView>(R.id.tvNotifDesc)
                    val tvTime = notifView.findViewById<TextView>(R.id.tvNotifTime)

                    tvTitle.text = notif.title
                    tvDesc.text = notif.description
                    tvTime.text = notif.time

                    // Set icon based on type
                    when (notif.type) {
                        "Class" -> imgIcon.setImageResource(R.drawable.ic_classes)
                        "Quiz" -> {
                            // Safe fallback for ic_quiz
                            try {
                                imgIcon.setImageResource(R.drawable.ic_quiz)
                            } catch (e: Exception) {
                                imgIcon.setImageResource(R.drawable.ic_book)
                            }
                        }
                        else -> imgIcon.setImageResource(R.drawable.ic_book)
                    }

                    notifView.setOnClickListener {
                        Toast.makeText(this, "Opening details for: ${notif.title}", Toast.LENGTH_SHORT).show()
                    }

                    notificationContainer.addView(notifView)
                }
            }
        }
    }


}
